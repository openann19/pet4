// Avatar glow pulse
export function PresenceGlow({ isActive }: { isActive: boolean }) {
  return <div className={`avatar ${isActive ? 'glow' : ''}`} />
}