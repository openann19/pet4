// Fade older messages
export function useMessageAgeEffect(timestamp: number) {
  return {} // Style with opacity decay
}