// AI reply shimmer/glow
export function AnimatedAIWrapper({ children }) {
  return <>{children}</> // Wrap with glow+shimmer
}