// Emoji trail effect
export function useReactionTrail() {
  // Trigger particle burst when user reacts
}