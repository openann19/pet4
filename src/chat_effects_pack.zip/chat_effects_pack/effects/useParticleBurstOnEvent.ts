// Trigger burst FX
export function useParticleBurstOnEvent(type: 'send' | 'delete' | 'reaction') {
  // spawn particle burst at location
}