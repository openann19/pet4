// Cross-platform haptics
export function useHapticFeedback(action: 'tap' | 'delete' | 'send') {
  // trigger haptic.impact()
}