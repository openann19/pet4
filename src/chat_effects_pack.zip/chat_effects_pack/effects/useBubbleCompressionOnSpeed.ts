// Compress bubble stack on rapid sends
export function useBubbleCompressionOnSpeed(rate: number) {
  return {} // Scale/margin compress
}