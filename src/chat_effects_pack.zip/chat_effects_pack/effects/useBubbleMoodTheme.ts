// Mood-based bubble background
export function useBubbleMoodTheme(text: string) {
  return 'bg-neutral-700' // Replace with tone detection logic
}