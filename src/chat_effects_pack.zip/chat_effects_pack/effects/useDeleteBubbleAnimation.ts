// Delete animation hook placeholder
export function useDeleteBubbleAnimation(onFinish: () => void) {
  // Implement withSharedValue for opacity, scale, height
}