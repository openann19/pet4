// Typing indicator dots
export function TypingDots() {
  return <></> // Replace with animated dots
}