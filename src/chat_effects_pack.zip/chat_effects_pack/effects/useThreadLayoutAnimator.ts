// Thread open animation
export function useThreadLayoutAnimator() {
  return {} // Animate thread into view
}