
import { useEffect } from 'react';
import { useMotionValue, animate, type MotionValue } from 'framer-motion';
import { springConfigs, timingConfigs } from './transitions';
import type { AnimatedStyle } from './animated-view';


export interface UseFadeAnimationOptions {
  initial?: boolean;
  duration?: number;
  enabled?: boolean;
  useSpring?: boolean;
}


export interface UseFadeAnimationReturn {
  animatedStyle: AnimatedStyle;
  opacity: MotionValue<number>;
  fadeIn: () => void;
  fadeOut: () => void;
  toggle: () => void;
}


export function useFadeAnimation(options: UseFadeAnimationOptions = {}): UseFadeAnimationReturn {
  const {
    initial = true,
    duration = timingConfigs.smooth.duration,
    enabled = true,
    useSpring = false,
  } = options;

  const opacity = useMotionValue(enabled ? (initial ? 1 : 0) : 1);

  const fadeIn = () => {
    if (!enabled) return;
    if (useSpring) {
      animate(opacity, 1, { type: 'spring', ...springConfigs.smooth });
    } else {
      animate(opacity, 1, { duration: (duration ?? 300) / 1000 });
    }
  };

  const fadeOut = () => {
    if (!enabled) return;
    if (useSpring) {
      animate(opacity, 0, { type: 'spring', ...springConfigs.smooth });
    } else {
      animate(opacity, 0, { duration: (duration ?? 300) / 1000 });
    }
  };

  const toggle = () => {
    if (opacity.get() > 0.5) {
      fadeOut();
    } else {
      fadeIn();
    }
  };

  useEffect(() => {
    if (!enabled) {
      opacity.set(1);
      return;
    }
    if (initial) {
      fadeIn();
    } else {
      fadeOut();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, initial]);

  const animatedStyle: AnimatedStyle = {
    opacity,
  };

  return {
    animatedStyle,
    opacity,
    fadeIn,
    fadeOut,
    toggle,
  };
}
