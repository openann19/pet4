'use client';

import { useState } from 'react';
import { AdoptionFiltersSheet } from '@/components/adoption/AdoptionFiltersSheet';
import { AdoptionListingDetailDialog } from '@/components/adoption/AdoptionListingDetailDialog';
import { CreateAdoptionListingDialog } from '@/components/adoption/CreateAdoptionListingDialog';
import { MyAdoptionApplications } from '@/components/adoption/MyAdoptionApplications';
import { MyAdoptionListings } from '@/components/adoption/MyAdoptionListings';
import { AdoptionListingItem } from '@/components/adoption/AdoptionListingItem';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SegmentedControl } from '@/components/ui/segmented-control';
import { PageTransitionWrapper } from '@/components/ui/page-transition-wrapper';
import type { AdoptionListing } from '@/lib/adoption-marketplace-types';
import { haptics } from '@/lib/haptics';
import { Check, Funnel, Heart, MagnifyingGlass, Plus, X, PawPrint, ClipboardText } from '@phosphor-icons/react';
import { MotionView } from '@petspark/motion';
import { AnimatePresence } from '@/effects/reanimated/animate-presence';
import { useAdoptionMarketplace } from '@/hooks/adoption/use-adoption-marketplace';
import { toast } from 'sonner';

type ViewTab = 'browse' | 'my-listings' | 'my-applications';

export default function AdoptionMarketplaceView() {
  const [activeTab, setActiveTab] = useState<ViewTab>('browse');
  const [showFilters, setShowFilters] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedListing, setSelectedListing] = useState<AdoptionListing | null>(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);

  const {
    listings,
    loading,
    searchQuery,
    setSearchQuery,
    filters,
    setFilters,
    currentUser,
    hasMore,
    loadListings,
    filteredListings,
    activeFilterCount,
  } = useAdoptionMarketplace();

  const handleCreateListing = () => {
    haptics.impact('medium');
    setShowCreateDialog(true);
  };

  const handleListingCreated = () => {
    setShowCreateDialog(false);
    toast.success('Adoption listing created! It will be reviewed by our team.');
    void loadListings();
  };

  const handleSelectListing = (listing: AdoptionListing) => {
    haptics.impact('light');
    setSelectedListing(listing);
    setShowDetailDialog(true);
  };

  const handleToggleFilters = () => {
    haptics.impact('light');
    setShowFilters((prev) => !prev);
  };

  return (
    <PageTransitionWrapper key="adoption-marketplace-view" direction="up">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h2 className="flex items-center gap-3 text-2xl font-semibold leading-[1.35] tracking-normal sm:text-[clamp(1.5rem,2.1vw,2rem)]">
              <Heart size={32} weight="fill" className="text-primary" />
              Adoption Marketplace
            </h2>
            <p className="mt-1 text-base leading-normal text-muted-foreground">
              Find your perfect companion and give them a loving forever home
            </p>
          </div>

          <Button onClick={handleCreateListing} className="gap-2" type="button">
            <Plus size={20} weight="bold" />
            List Pet
          </Button>
        </div>

        {/* Tabs */}
        <SegmentedControl
          options={[
            {
              value: 'browse',
              label: 'Browse',
              icon: <MagnifyingGlass size={20} weight="bold" />,
            },
            {
              value: 'my-listings',
              label: 'My Listings',
              icon: <PawPrint size={20} weight="fill" />,
            },
            {
              value: 'my-applications',
              label: 'Applications',
              icon: <ClipboardText size={20} weight="fill" />,
            },
          ]}
          value={activeTab}
          onChange={(value) => setActiveTab(value as ViewTab)}
          fullWidth
          className="mb-6"
        />

        <div className="mt-6">
          {/* Browse Tab */}
          {activeTab === 'browse' && (
            <div className="space-y-4">
              {/* Search + Filters */}
              <div className="flex flex-col gap-3 rounded-xl border border-border/50 bg-gradient-to-br from-muted/30 via-muted/20 to-muted/10 p-4 shadow-sm backdrop-blur-sm sm:flex-row">
                <div className="relative flex-1">
                  <MagnifyingGlass
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                    size={20}
                    weight="bold"
                  />
                  <Input
                    placeholder="Search by name, breed, or location..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="border-border/50 bg-background/50 pl-10 backdrop-blur-sm"
                  />
                </div>

                <Button
                  variant="outline"
                  onClick={handleToggleFilters}
                  className="relative gap-2 border-border/50 bg-background/50 backdrop-blur-sm transition-all hover:bg-background/80"
                  type="button"
                >
                  <Funnel size={20} weight="bold" />
                  Filters
                  {activeFilterCount > 0 && (
                    <Badge variant="secondary" className="ml-1 min-w-[20px]">
                      {activeFilterCount}
                    </Badge>
                  )}
                </Button>
              </div>

              {/* Active Filters */}
              {activeFilterCount > 0 && (
                <div className="flex flex-wrap gap-2">
                  {filters.breed &&
                    filters.breed.length > 0 &&
                    filters.breed.map((breed) => (
                      <Badge key={breed} variant="secondary" className="gap-1">
                        {breed}
                        <X
                          size={14}
                          className="cursor-pointer hover:text-destructive"
                          onClick={() => {
                            setFilters((prev) => {
                              const next = { ...prev };
                              const newBreed = prev.breed?.filter((b: string) => b !== breed);
                              if (!newBreed || newBreed.length === 0) {
                                delete next.breed;
                              } else {
                                next.breed = newBreed;
                              }
                              return next;
                            });
                          }}
                        />
                      </Badge>
                    ))}

                  {filters.vaccinated && (
                    <Badge variant="secondary" className="gap-1">
                      <Check size={14} /> Vaccinated
                      <X
                        size={14}
                        className="cursor-pointer hover:text-destructive"
                        onClick={() =>
                          setFilters((prev) => {
                            const next = { ...prev };
                            delete next.vaccinated;
                            return next;
                          })
                        }
                      />
                    </Badge>
                  )}

                  {filters.spayedNeutered && (
                    <Badge variant="secondary" className="gap-1">
                      <Check size={14} /> Spayed/Neutered
                      <X
                        size={14}
                        className="cursor-pointer hover:text-destructive"
                        onClick={() =>
                          setFilters((prev) => {
                            const next = { ...prev };
                            delete next.spayedNeutered;
                            return next;
                          })
                        }
                      />
                    </Badge>
                  )}

                  <Button
                    variant="ghost"
                    size="sm"
                    type="button"
                    onClick={() => setFilters({})}
                    className="h-6 px-2 text-xs"
                  >
                    Clear All
                  </Button>
                </div>
              )}

              {/* Listings */}
              {loading && listings.length === 0 ? (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    // eslint-disable-next-line react/no-array-index-key
                    <div key={i} className="h-96 animate-pulse rounded-2xl bg-muted" />
                  ))}
                </div>
              ) : filteredListings.length === 0 ? (
                <MotionView
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, ease: [0.22, 0.61, 0.36, 1] }}
                  className="flex flex-col items-center justify-center py-16 text-center"
                >
                  <Heart size={64} className="mb-4 text-muted-foreground" weight="thin" />
                  <h3 className="mb-2 text-xl font-semibold">
                    {searchQuery ? 'No results found' : 'No pets available'}
                  </h3>
                  <p className="max-w-md text-sm text-muted-foreground">
                    {searchQuery
                      ? 'Try adjusting your search or filters'
                      : 'Check back soon for new pets looking for their forever homes.'}
                  </p>
                </MotionView>
              ) : (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                  <AnimatePresence mode="popLayout">
                    {filteredListings.map((listing, index) => (
                      <AdoptionListingItem
                        key={listing.id}
                        listing={listing}
                        index={index}
                        onSelect={() => handleSelectListing(listing)}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              )}

              {/* Load more */}
              {hasMore && (
                <div className="flex justify-center pt-4">
                  <Button
                    variant="outline"
                    type="button"
                    onClick={() => {
                      void loadListings(false);
                    }}
                    disabled={loading}
                  >
                    {loading ? 'Loading...' : 'Load More'}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* My Listings */}
          {activeTab === 'my-listings' && currentUser && (
            <MyAdoptionListings userId={currentUser.id} />
          )}

          {/* My Applications */}
          {activeTab === 'my-applications' && currentUser && (
            <MyAdoptionApplications userId={currentUser.id} />
          )}
        </div>

        {/* Dialogs */}
        <CreateAdoptionListingDialog
          open={showCreateDialog}
          onOpenChange={setShowCreateDialog}
          onSuccess={handleListingCreated}
        />

        <AdoptionListingDetailDialog
          listing={selectedListing}
          open={showDetailDialog}
          onOpenChange={(open) => {
            setShowDetailDialog(open);
            if (!open) setSelectedListing(null);
          }}
          onApplicationSubmitted={() => {
            // fix: no-floating-promises → explicitly mark we ignore the Promise
            void loadListings();
            toast.success('Application submitted successfully!');
          }}
        />

        <AdoptionFiltersSheet
          open={showFilters}
          onOpenChange={setShowFilters}
          filters={filters}
          onFiltersChange={setFilters}
        />
      </div>
    </PageTransitionWrapper>
  );
}
