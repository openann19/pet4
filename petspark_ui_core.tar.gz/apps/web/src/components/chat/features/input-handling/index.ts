export { useInputHandling } from './use-input-handling';
export type { UseInputHandlingOptions, UseInputHandlingReturn } from './use-input-handling';
