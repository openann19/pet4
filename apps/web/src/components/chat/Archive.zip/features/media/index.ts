export { useMedia } from './use-media'
export type { UseMediaOptions, UseMediaReturn } from './use-media'

