/**
 * Typing Indicator "Liquid Dots" Effect Hook
 * 
 * Creates a premium typing indicator with:
 * - Three dots moving with phase-shifted sine waves
 * - Y-offset 0→5px, opacity 0.6→1.0
 * - Skia blur + bloom at 0.85 intensity
 * - CPU cost <0.8ms/frame
 * - Reduced Motion → static pulsing opacity at 0.8 Hz
 * 
 * Location: apps/mobile/src/effects/chat/typing/use-liquid-dots.ts
 */

import { useCallback, useEffect } from 'react'
import {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated'
import { createLogger } from '../../../utils/logger'
import { useReducedMotionSV } from '../core/reduced-motion'
import { getBloomImageFilter } from '../shaders/bloom'
import { getCachedBlurFilter } from '../shaders/blur'

const logger = createLogger('liquid-dots')

/**
 * Dot configuration
 */
interface DotConfig {
  phase: number // phase offset in radians
  yOffset: SharedValue<number>
  opacity: SharedValue<number>
}

/**
 * Liquid dots effect options
 */
export interface UseLiquidDotsOptions {
  enabled?: boolean
  dotSize?: number
  dotColor?: string
  dotSpacing?: number
}

/**
 * Liquid dots effect return type
 */
export interface UseLiquidDotsReturn {
  dots: Array<DotConfig>
  animatedStyle: ReturnType<typeof useAnimatedStyle>
  blurFilter: ReturnType<typeof getCachedBlurFilter>
  bloomConfig: ReturnType<typeof getBloomImageFilter>
}

const DEFAULT_ENABLED = true
const DEFAULT_DOT_SIZE = 6
const DEFAULT_DOT_COLOR = '#666666'
const ANIMATION_DURATION = 1200 // ms per cycle
const PULSE_DURATION = 1250 // ms for reduced motion (0.8 Hz = 1.25s period)

export function useLiquidDots(
  options: UseLiquidDotsOptions = {}
): UseLiquidDotsReturn {
  const {
    enabled = DEFAULT_ENABLED,
    dotSize = DEFAULT_DOT_SIZE,
    dotColor = DEFAULT_DOT_COLOR,
  } = options

  const reducedMotion = useReducedMotionSV()

  // Three dots with phase-shifted animations
  const dot1Y = useSharedValue(0)
  const dot1Opacity = useSharedValue(0.6)
  const dot2Y = useSharedValue(0)
  const dot2Opacity = useSharedValue(0.6)
  const dot3Y = useSharedValue(0)
  const dot3Opacity = useSharedValue(0.6)

  const dots: Array<DotConfig> = [
    { phase: 0, yOffset: dot1Y, opacity: dot1Opacity },
    { phase: (Math.PI * 2) / 3, yOffset: dot2Y, opacity: dot2Opacity },
    { phase: (Math.PI * 4) / 3, yOffset: dot3Y, opacity: dot3Opacity },
  ]

  const startAnimation = useCallback(() => {
    const isReducedMotion = reducedMotion.value

    if (isReducedMotion) {
      // Reduced Motion: Static pulsing opacity at 0.8 Hz
      const pulseOpacity = withRepeat(
        withSequence(
          withTiming(0.8, {
            duration: PULSE_DURATION / 2,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(0.6, {
            duration: PULSE_DURATION / 2,
            easing: Easing.inOut(Easing.ease),
          })
        ),
        -1,
        false
      )

      dot1Opacity.value = pulseOpacity
      dot2Opacity.value = pulseOpacity
      dot3Opacity.value = pulseOpacity
    } else {
      // Normal: Phase-shifted sine waves
      // Dot 1
      dot1Y.value = withRepeat(
        withTiming(5, {
          duration: ANIMATION_DURATION,
          easing: Easing.inOut(Easing.sin),
        }),
        -1,
        true
      )
      dot1Opacity.value = withRepeat(
        withTiming(1.0, {
          duration: ANIMATION_DURATION,
          easing: Easing.inOut(Easing.sin),
        }),
        -1,
        true
      )

      // Dot 2 (phase-shifted)
      setTimeout(() => {
        dot2Y.value = withRepeat(
          withTiming(5, {
            duration: ANIMATION_DURATION,
            easing: Easing.inOut(Easing.sin),
          }),
          -1,
          true
        )
        dot2Opacity.value = withRepeat(
          withTiming(1.0, {
            duration: ANIMATION_DURATION,
            easing: Easing.inOut(Easing.sin),
          }),
          -1,
          true
        )
      }, ANIMATION_DURATION / 3)

      // Dot 3 (phase-shifted)
      setTimeout(() => {
        dot3Y.value = withRepeat(
          withTiming(5, {
            duration: ANIMATION_DURATION,
            easing: Easing.inOut(Easing.sin),
          }),
          -1,
          true
        )
        dot3Opacity.value = withRepeat(
          withTiming(1.0, {
            duration: ANIMATION_DURATION,
            easing: Easing.inOut(Easing.sin),
          }),
          -1,
          true
        )
      }, (ANIMATION_DURATION * 2) / 3)
    }
  }, [reducedMotion, dot1Y, dot1Opacity, dot2Y, dot2Opacity, dot3Y, dot3Opacity])

  useEffect(() => {
    if (enabled) {
      startAnimation()
    } else {
      // Reset values
      dot1Y.value = 0
      dot1Opacity.value = 0.6
      dot2Y.value = 0
      dot2Opacity.value = 0.6
      dot3Y.value = 0
      dot3Opacity.value = 0.6
    }
  }, [enabled, startAnimation, dot1Y, dot1Opacity, dot2Y, dot2Opacity, dot3Y, dot3Opacity])

  const animatedStyle = useAnimatedStyle(() => {
    // This style is applied to the container
    // Individual dot styles are handled in the Skia component
    return {}
  })

  // Get blur and bloom filters for Skia rendering
  const blurFilter = getCachedBlurFilter({ radius: 4 }) // subtle blur
  const bloomConfig = getBloomImageFilter({ intensity: 0.85, radius: 4 })

  logger.debug('Liquid dots initialized', {
    enabled,
    dotSize,
    dotColor,
    reducedMotion: reducedMotion.value,
  })

  return {
    dots,
    animatedStyle,
    blurFilter,
    bloomConfig,
  }
}

