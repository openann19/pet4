/**
 * Reactions Effects Index
 * 
 * Exports reaction effect hooks:
 * - Reaction burst
 * 
 * Location: apps/mobile/src/effects/chat/reactions/index.ts
 */

export * from './use-reaction-burst';

