/**
 * Mobile Animation Hooks Index
 * Exports all Reanimated animation hooks for mobile platform
 */

// Core components
export { AnimatedView, type AnimatedStyle } from './animated-view'

// Transitions
export { springConfigs, timingConfigs, validateSpringConfig, type SpringConfig, type TimingConfig } from './transitions'

// Navigation hooks
export { useNavButtonAnimation, type UseNavButtonAnimationOptions, type UseNavButtonAnimationReturn } from './use-nav-button-animation'
export { useHeaderButtonAnimation, type UseHeaderButtonAnimationOptions, type UseHeaderButtonAnimationReturn } from './use-header-button-animation'
export { useNavBarAnimation, type UseNavBarAnimationOptions, type UseNavBarAnimationReturn } from './use-nav-bar-animation'

// Hover/Press effects (adapted for mobile)
export { useHoverLift, type UseHoverLiftOptions, type UseHoverLiftReturn } from './use-hover-lift'
export { useMagneticPress, type UseMagneticPressOptions, type UseMagneticPressReturn } from './use-magnetic-press'
export { useMagneticEffect, type UseMagneticEffectOptions, type UseMagneticEffectReturn } from './use-magnetic-effect'
export { useHoverAnimation, type UseHoverAnimationOptions, type UseHoverAnimationReturn } from './use-hover-animation'
export { useHoverTap, type UseHoverTapOptions, type UseHoverTapReturn } from './use-hover-tap'

// Visual effects
export { useGlowPulse, type UseGlowPulseOptions, type UseGlowPulseReturn } from './use-glow-pulse'
export { useShimmer, type UseShimmerOptions, type UseShimmerReturn } from './use-shimmer'
export { useGradientAnimation, type UseGradientAnimationOptions, type UseGradientAnimationReturn } from './use-gradient-animation'
export { useShimmerSweep, type UseShimmerSweepOptions, type UseShimmerSweepReturn } from './use-shimmer-sweep'
export { useConfettiBurst, type UseConfettiBurstOptions, type UseConfettiBurstReturn, type ConfettiParticle } from './use-confetti-burst'
export { useElasticScale, type UseElasticScaleOptions, type UseElasticScaleReturn } from './use-elastic-scale'
export { useGlowBorder, type UseGlowBorderOptions, type UseGlowBorderReturn } from './use-glow-border'
export { useBreathingAnimation, type UseBreathingAnimationOptions, type UseBreathingAnimationReturn } from './use-breathing-animation'
export { useReceiptTransition, type UseReceiptTransitionOptions, type UseReceiptTransitionReturn } from './use-receipt-transition'
export { useTypingShimmer, type UseTypingShimmerOptions, type UseTypingShimmerReturn } from './use-typing-shimmer'
export { useTimestampReveal, type UseTimestampRevealOptions, type UseTimestampRevealReturn } from './use-timestamp-reveal'

// Transition hooks
export { useEntryAnimation, type UseEntryAnimationOptions, type UseEntryAnimationReturn } from './use-entry-animation'
export { useModalAnimation, type UseModalAnimationOptions, type UseModalAnimationReturn } from './use-modal-animation'
export { usePageTransition, type UsePageTransitionOptions, type UsePageTransitionReturn } from './use-page-transition'
export { usePageTransitionWrapper, type UsePageTransitionWrapperOptions, type UsePageTransitionWrapperReturn } from './use-page-transition-wrapper'
export { useHeaderAnimation, type UseHeaderAnimationOptions, type UseHeaderAnimationReturn } from './use-header-animation'
export { useSidebarAnimation, type UseSidebarAnimationOptions, type UseSidebarAnimationReturn } from './use-sidebar-animation'
export { useExpandCollapse, type UseExpandCollapseOptions, type UseExpandCollapseReturn } from './use-expand-collapse'
export { useRotation, type UseRotationOptions, type UseRotationReturn } from './use-rotation'
export { useIconRotation, type UseIconRotationOptions, type UseIconRotationReturn } from './use-icon-rotation'
export { useLogoAnimation, type UseLogoAnimationReturn } from './use-logo-animation'
export { useLogoGlow, type UseLogoGlowReturn } from './use-logo-animation'

// Existing hooks
export { useBounceOnTap } from './use-bounce-on-tap'
export { useRippleEffect } from './use-ripple-effect'
export { useStaggeredContainer } from './use-staggered-container'
export { useStaggeredItem } from './use-staggered-item'
export { useStickerAnimation } from './use-sticker-animation'

// Ultra Enhanced Animations
export { useUltraCardReveal } from './use-ultra-card-reveal'
export { useMorphShape } from './use-morph-shape'
export { use3DFlipCard } from './use-3d-flip-card'
export { useSpringCarousel } from './use-spring-carousel'
export { useWaveAnimation, useMultiWave } from './use-wave-animation'

// Re-export commonly used Reanimated primitives
export {
  useSharedValue,
  useAnimatedStyle,
  useAnimatedProps,
  useAnimatedReaction,
  useDerivedValue,
  useAnimatedRef,
  withSpring,
  withTiming,
  withRepeat,
  withSequence,
  withDelay,
  withDecay,
  cancelAnimation,
  runOnJS,
  runOnUI,
  Easing,
  interpolate,
  Extrapolation,
  type SharedValue,
} from 'react-native-reanimated'
